import DecisionTree
import Testing

Testing.testDummySet1()
Testing.testDummySet2()
Testing.testConnect4()
Testing.testCar()
